#include <stdio.h>
#include <stdlib.h>

int findMin(int *arr, int size) {
    int min = arr[0];
    for (int i = 1; i < size; i++) {
        if (arr[i] < min) {
            min = arr[i];
        }
    }
    return min;
}

int findMax(int *arr, int size) {
    int max = arr[0];
    for (int i = 1; i < size; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}

int main() {
    int n;
    
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    
    int *arr = (int *)malloc(n * sizeof(int));

    
    if (arr == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }


    printf("Enter the elements:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    
    int min = findMin(arr, n);
    int max = findMax(arr, n);
    printf("Minimum number: %d\n", min);
    printf("Maximum number: %d\n", max);

    
    free(arr);

    return 0;
}
