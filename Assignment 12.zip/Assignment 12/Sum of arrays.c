#include <stdio.h>
#include<stdlib.h>
int main() {
	int n;
	printf("Enter number of elements in the  1St array: ");
	scanf("%d", &n);
	int* arr=(int*)malloc(n*sizeof(int));
	if(arr==NULL)
	{
		printf("Memory Allocation failed");
		return 1;
	}

	 arr[n];
	printf("Enter %d elements in the array: ",n);
	for(int i=0; i<n; i++) {
		scanf("%d",&arr[i]);
	}
	printf("Enter number of elements in the 2nd array: ");
	scanf("%d", &n);
	int* brr=(int*)malloc(n*sizeof(int));
	if(brr==NULL)
	{
		printf("Memory Allocation failed");
		return 1;
	}

	 brr[n];
	printf("Enter %d elements in the array: ",n);
	for(int i=0; i<n; i++) {
		scanf("%d",&brr[i]);
	}
	int* crr=(int*)malloc(n*sizeof(int));
	if(crr==NULL)
	{
		printf("Memory Allocation failed");
		return 1;
	}
	crr[n];
	for(int i=0;i<n;i++)
	{
		crr[i]=arr[i]+brr[i];
	}
	
	printf("Sum of arrays:-");	
	for(int i=0;i<n;i++)
	{
		printf("\ncrr[%d]=%d",i,crr[i]);	
	}
}