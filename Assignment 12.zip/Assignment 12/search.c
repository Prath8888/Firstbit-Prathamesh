#include <stdio.h>
#include <stdlib.h>
int numbersearch(int *, int * );
int main() {
	int input;
	printf("enter the number of values to enter : ");
	scanf("%d", &input);
	
	int *arr = (int *)malloc(input * sizeof(int));

    // Check if memory allocation was successful
    if (arr == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

  
	
	arr[input];
	for (int i = 0; i < input; i++) {
		printf("enter the %d element : ", i + 1);
		scanf("%d", &arr[i]);
	}
	numbersearch(arr, &input );
}
int numbersearch(int *arr, int *input ) {
	int search;
	printf("enter a number to search in array ");
	scanf("%d", &search);
	int flag = 0;
	int j;
	for (j = 0; j < *input; j++) {
		if (search == arr[j]) {
			flag = 1;
			break;
		}
	}
	if (flag == 1) {
		printf("element %d is present in array at %d location ", search,j);
	} else
		printf(" %d is not present in array ", search);
}