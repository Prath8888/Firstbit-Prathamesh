#include <stdio.h>
#include <stdlib.h>
int main() {
	int n;            //Array Size Declaration
	printf("Enter the size of first array: ");
	scanf("%d",&n);
	int* arr=(int*)malloc(n*sizeof(int));
	if(arr==NULL)
	{
		printf("Memory Allocation failed");
		return 1;
	}
	arr[n];
	printf("Enter the array elements: ");
	for(int i = 0; i < n; i++)
		scanf("%d", &arr[i]);
	printf("\nFinal array after sorting: ");
	for(int i = 0; i < n; i++) {
		int temp;
		for(int j = i + 1; j < n; j++) {
			if(arr[i] > arr[j]) {
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}
	for(int i = 0; i < n ; i++)       //Print the sorted Array
		printf(" %d ",arr[i]);
	}
