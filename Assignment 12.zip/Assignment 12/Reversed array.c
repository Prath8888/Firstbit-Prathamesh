#include <stdio.h>
#include <stdlib.h>
int main(){
int n;            //Array Size Declaration

printf("Enter the size of first array: ");
scanf("%d",&n);
int* arr=(int*)malloc(n*sizeof(int));
	if(arr==NULL)
	{
		printf("Memory Allocation failed");
		return 1;
	}
	arr[n];
printf("Enter the array elements: ");
for(int i = 0; i < n; i++)
	scanf("%d", &arr[i]);
int rev[n], j = 0;
for(int i = n-1; i >= 0; i--)
 {
	rev[j] = arr[i];
	j++;
}
printf("The Reversed array: ");
for(int i = 0; i < n; i++) {
	printf("%d ", rev[i]);
}
}
