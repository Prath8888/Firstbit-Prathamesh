#include <stdio.h>
#include <stdlib.h>
int evenodd(int *arr, int *input);
int main() {
	int input;
	printf("enter the number of values to enter :");
	scanf("%d", &input);
	int *
	arr=(int*)malloc(input* sizeof(int));
	if(arr==NULL)
	{
		printf("Memory Allocation failed.\n");
		return 1;
	}
	 arr[input];
	for (int i = 0; i < input; i++) {
		printf("enter the %d element : ", i + 1);
		scanf("%d", &arr[i]);
	}
	evenodd(arr, &input);
}

int evenodd(int *arr, int *input) {
	for (int j = 0; j < *input; j++) {
		if (arr[j] % 2 == 0) {
			printf("%d is a even number\n", arr[j]);
		} else
			printf("%d is a odd number\n", arr[j]);
	}
}