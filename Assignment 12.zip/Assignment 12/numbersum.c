#include <stdio.h>
#include <stdlib.h>
int numbersum(int*,int*);
int main() {
	int input;
	printf("enter the number of values to entr:");
	scanf("%d",&input);
	
	int *arr=(int*)malloc(input* sizeof(int));
	if (arr == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }
  arr[input];
	for (int i=0; i<input; i++) {
		printf("enter the %d element : ",i+1);
		scanf("%d",&arr[i]);
	}
	printf("\nsum of numbers : %d",numbersum(arr,&input));
}
int numbersum(int* arr,int* input) {
	int sum=0;
	for (int a=0; a<*input; a++) {
		int sum=0;
		for (int a=0; a<*input; a++) {
			sum=arr[a]+sum;
		}
		return sum;
	}
}