#include <stdio.h>
#include <string.h>

struct Course    {
    
    char coursename[50];
    float courseprice;
    int duration;
    
};

int main() {
    struct Course c1;

    

    strcpy(c1.coursename, "Full stack combo java"); 
    c1.courseprice = 29500.00;
    c1.duration=6;
    


    printf("Course Details:\n");
    printf("Course Name: %d\n", c1.coursename);
    printf(" Course Price: %s\n", c1.courseprice);
    printf("Duration of a Course is: %.2f\n", c1.duration);
    

    return 0;
}
