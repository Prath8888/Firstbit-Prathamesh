#include <stdio.h>
#include <string.h>

// Define the structure for Product
struct Product {
    int id;
    char name[50];
    int quantity;
    float price;
};

// Function prototypes
void store(struct Product *prod, int id, const char *name, int quantity, float price);
void display(struct Product prod);            
void displayByAddress(struct Product *prod);  

int main() {
    // Declare an array of Product structures
    struct Product products[2];

    // Store values using the store function
    store(&products[0], 101, "Laptop", 10, 999.99);
    store(&products[1], 102, "Smartphone", 20, 499.99);

    // Display products by value
    printf("Display by value:\n");
    display(products[0]);
    display(products[1]);

    // Display products by address
    printf("\nDisplay by address:\n");
    displayByAddress(&products[0]);
    displayByAddress(&products[1]);

    return 0;
}

// Function to store product values
void store(struct Product *prod, int id, const char *name, int quantity, float price) {
    prod->id = id;
    strcpy(prod->name, name); // Copying string into char array
    prod->quantity = quantity;
    prod->price = price;
}

// Function to display product (pass by value)
void display(struct Product prod) {
    printf("Product ID: %d\n", prod.id);
    printf("Name: %s\n", prod.name);
    printf("Quantity: %d\n", prod.quantity);
    printf("Price: $%.2f\n", prod.price);
    printf("\n");
}

// Function to display product (pass by address)
void displayByAddress(struct Product *prod) {
    printf("Product ID: %d\n", prod->id);
    printf("Name: %s\n", prod->name);
    printf("Quantity: %d\n", prod->quantity);
    printf("Price: $%.2f\n", prod->price);
    printf("\n");
}
