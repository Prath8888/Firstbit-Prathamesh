#include <stdio.h>


struct Time {
    int hour;
    float min;
    float sec;
};


void inputTime(struct Time *time) {
    printf("Enter Hour: ");
    scanf("%d", &time->hour);
    printf("Enter Minute: ");
    scanf("%f", &time->min);
    printf("Enter second: ");
    scanf("%f", &time->sec);
}


void displayTime(struct Time time) {
    printf("\nHour: %d\n", time.hour);
    printf("Min: %f\n", time.min);
    printf("Second: %f\n", time.sec);
}

int main() {
    struct Time time;


    inputTime(&time);
    displayTime(time);

    return 0;
}