#include <stdio.h>
#include <string.h>

// Define the structure for Movie
struct Movie {
    char title[100];
    char director[50];
    int duration; // Duration in minutes
};

void displayMovie(struct Movie movie);

int main() {
    struct Movie movie1;

    // Assign values to the Movie structure
    strcpy(movie1.title, "Inception");
    strcpy(movie1.director, "Christopher Nolan");
    movie1.duration = 148;

    // Display movie details
    displayMovie(movie1);

    return 0;
}

void displayMovie(struct Movie movie) {
    printf("Title: %s\n", movie.title);
    printf("Director: %s\n", movie.director);
    printf("Duration: %d minutes\n", movie.duration);
}
