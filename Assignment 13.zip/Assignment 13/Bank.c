#include <stdio.h>
#include <string.h>

// Define the structure for BankAccount
struct BankAccount {
    int accountNumber;
    char holderName[50];
    double balance;
};

void displayAccount(struct BankAccount account);

int main() {
    struct BankAccount account1;

    // Assign values to the BankAccount structure
    account1.accountNumber = 123456789;
    strcpy(account1.holderName, "Michael Johnson");
    account1.balance = 15000.75;

    // Display bank account details
    displayAccount(account1);

    return 0;
}

void displayAccount(struct BankAccount account) {
    printf("Account Number: %d\n", account.accountNumber);
    printf("Holder Name: %s\n", account.holderName);
    printf("Balance: $%.2f\n", account.balance);
}
