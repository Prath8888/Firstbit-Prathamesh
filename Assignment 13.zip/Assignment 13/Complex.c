#include <stdio.h>


struct Complex {
    double real;
    double imaginary;
};

int main() {
    
    struct Complex num1, num2, sum;

    
    num1.real = 3.0;
    num1.imaginary = 4.0;

    
    num2.real = 1.5;
    num2.imaginary = 2.5;

    
    sum.real = num1.real + num2.real;
    sum.imaginary = num1.imaginary + num2.imaginary;

   
    printf("First Complex Number: %.2f + %.2fi\n", num1.real, num1.imaginary);
    printf("Second Complex Number: %.2f + %.2fi\n", num2.real, num2.imaginary);
    printf("Sum of Complex Numbers: %.2f + %.2fi\n", sum.real, sum.imaginary);

    return 0;
}
