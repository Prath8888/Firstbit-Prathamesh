#include <stdio.h>
#include <string.h>

struct Train    {
    int Trainid;
    char Trainname[50];
    float Arrivaltime;
    float Departuretime;
    
};

int main() {
    struct Train tr;

    
    tr.Trainid = 17013;
    strcpy(tr.Trainname, "Panvel Express"); 
    tr.Arrivaltime = 19.30;
    tr.Departuretime=19.35;
    


    printf("TRAIN Details:\n");
    printf("TrainID: %d\n", tr.Trainid);
    printf(" Train Name: %s\n", tr.Trainname);
    printf("Arrival Time of a train is: %.2f\n", tr.Arrivaltime);
    printf("Departure Time of a train is:%.2f\n",tr.Departuretime);
     

    return 0;
}
