#include <stdio.h>
#include <string.h>

// Define the structure for Book
struct Book {
    char title[100];
    char author[50];
    float price;
};

void displayBook(struct Book book);

int main() {
    struct Book book1;

    // Assign values to the Book structure
    strcpy(book1.title, "The Great Gatsby");
    strcpy(book1.author, "F. Scott Fitzgerald");
    book1.price = 15.99;

    // Display book details
    displayBook(book1);

    return 0;
}

void displayBook(struct Book book) {
    printf("Title: %s\n", book.title);
    printf("Author: %s\n", book.author);
    printf("Price: $%.2f\n", book.price);
}
