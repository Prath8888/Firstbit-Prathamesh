#include <stdio.h>

// Define the structure for Weather
struct Weather {
    float temperature;
    int humidity;
    float windSpeed;
};

void displayWeather(struct Weather weather);

int main() {
    struct Weather today;

    // Assign values to the Weather structure
    today.temperature = 29.5;
    today.humidity = 65;
    today.windSpeed = 10.2;

    // Display weather data
    displayWeather(today);

    return 0;
}

void displayWeather(struct Weather weather) {
    printf("Temperature: %.2f°C\n", weather.temperature);
    printf("Humidity: %d%%\n", weather.humidity);
    printf("Wind Speed: %.2f km/h\n", weather.windSpeed);
}
