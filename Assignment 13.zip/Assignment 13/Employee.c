#include <stdio.h>


struct Employee {
    int id;
    char name[50];
    float salary;
};


void inputEmployee(struct Employee *e1) {
    printf("Enter Employee ID: ");
    scanf("%d", &e1->id);
    printf("Enter Employee name: ");
    scanf("%s", e1->name);
    printf("Enter Employee salary: ");
    scanf("%f", &e1->salary);
}


void displayEmployee(struct Employee e1) {
    printf("\nEmployee ID: %d\n", e1.id);
    printf("Employee Name: %s\n", e1.name);
    printf("Employee salary: %.2f\n", e1.salary);
}

int main() {
    struct Employee e1;


    inputEmployee(&e1);
    displayEmployee(e1);

    return 0;
}