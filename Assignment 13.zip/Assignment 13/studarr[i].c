#include <stdio.h>


struct Student {
    int id;
    char name[50];
    float marks;
};


void inputStudent( Student* studarr,int size) {
	for(int i=0;i<size;i++){
	
    printf("Enter student ID: ");
    scanf("%d", &studarr[i]->id);
    printf("Enter student name: ");
    scanf("%s", studarr[i]->name);
    printf("Enter student marks: ");
    scanf("%f", &studarr[i]->marks);
}
}


void displayStudent(struct Student studarr[10]) {
    printf("\nStudent ID: %d\n", studarr[i].id);
    printf("Student Name: %s\n", studarr[i].name);
    printf("Student Marks: %.2f\n", studarr[i].marks);
}
 
int main() {
    struct Student studarr[10];


    inputStudent(&stud[10]);
    displayStudent(stud[10]);

    return 0;
}