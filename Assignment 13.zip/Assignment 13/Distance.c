 #include <stdio.h>
struct Distance {
    int feet;
    float inch;
};

int main() {
    
    struct Distance dist;

    
    dist.feet = 5;
    dist.inch = 9.25;

    
    printf("Distance:\n");
    printf("Feet: %d\n", dist.feet);
    printf("Inches: %.2f\n", dist.inch);

    return 0;
}
