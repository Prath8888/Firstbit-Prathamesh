#include <stdio.h>


struct SalesManager {
    int id;
    char name[50];
    float salary;
    float incentive;
    float target;
};

void inputSalesManager(struct SalesManager *sr1) {
    printf("Enter SalesManager ID: ");
    scanf("%d", &sr1->id);
    printf("Enter SalesManager name: ");
    scanf("%s", sr1->name);
    printf("Enter SalesManager salary: ");
    scanf("%f", &sr1->salary);
    printf("Enter SalesManager incentive: ");
    scanf("%f", &sr1->incentive);
    printf("Enter SalesManager target: ");
    scanf("%f", &sr1->target);
}


void displaySalesManager(struct SalesManager sr1) {
    printf("\nSalesManager ID: %d\n", sr1.id);
    printf("SalesManager Name: %s\n", sr1.name);
    printf("SalesManager salary: %.2f\n", sr1.salary);
    printf("SalesManager: %.2f\n", sr1.incentive);
    printf("SalesManager: %.2f\n", sr1.target);
}

int main() {
    struct SalesManager sr1;


    inputSalesManager(&sr1);
    displaySalesManager(sr1);

    return 0;
}