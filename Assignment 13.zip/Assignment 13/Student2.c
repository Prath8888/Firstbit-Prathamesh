#include <stdio.h>


struct Student {
    int id;
    char name[50];
    float marks;
};
void main()
{
	store();
	Display();
}

store()
{
struct Student s;

	printf("Enter student ID: ");
    scanf("%d", &s.id);
    printf("Enter student name: ");
    scanf("%s", s.name);
    printf("Enter student marks: ");
    scanf("%f", &s.marks);
    return s;

}
Display() {

    printf("\nStudent ID: %d\n", s.id);
    printf("Student Name: %s\n", s.name);
    printf("Student Marks: %.2f\n", s.marks);
}