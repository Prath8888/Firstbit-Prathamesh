#include <stdio.h>


struct HR {
    int id;
    char name[50];
    float salary;
    float Commission;
};


void inputHR(struct HR *hr1) {
    printf("Enter HR ID: ");
    scanf("%d", &hr1->id);
    printf("Enter HR name: ");
    scanf("%s", hr1->name);
    printf("Enter HR salary: ");
    scanf("%f", &hr1->salary);
    printf("Enter HR Commission: ");
    scanf("%f", &hr1->Commission);
}


void displayHR(struct HR hr1) {
    printf("\nHR ID: %d\n", hr1.id);
    printf("HR Name: %s\n", hr1.name);
    printf("HR salary: %.2f\n", hr1.salary);
    printf("Commission: %.2f\n", hr1.Commission);
}

int main() {
    struct HR hr1;


    inputHR(&hr1);
    displayHR(hr1);

    return 0;
}