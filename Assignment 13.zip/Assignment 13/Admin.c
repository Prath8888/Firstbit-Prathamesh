#include <stdio.h>


struct Admin {
    int id;
    char name[50];
    float salary;
    float allowance;
};


void inputAdmin(struct Admin *admin1) {
    printf("Enter Admin ID: ");
    scanf("%d", &admin1->id);
    printf("Enter Admin name: ");
    scanf("%s", admin1->name);
    printf("Enter Admin salary: ");
    scanf("%f", &admin1->salary);
    printf("Enter Admin Allowance: ");
    scanf("%f", &admin1->allowance);
}


void displayAdmin(struct Admin admin1) {
	printf("\n----------------------\n");
    printf("\nAdmin ID: %d\n", admin1.id);
    printf("Admin Name: %s\n", admin1.name);
    printf("Admin salary: %.2f\n", admin1.salary);
    printf("Allowance: %.2f\n", admin1.allowance);
    printf("\n----------------------\n");
}

int main() {
    struct Admin admin1;


    inputAdmin(&admin1);
    displayAdmin(admin1);

    return 0;
}