#include <stdio.h>


struct Date {
    int date;
    int month;
    int year;
};


void inputDate(struct Date *d1) {
    printf("Enter Date: ");
    scanf("%d", &d1->date);
    printf("Enter Month: ");
    scanf("%d", d1->month);
    printf("Enter year: ");
    scanf("%d", &d1->year);
}


void displayDate(struct Date d1) {
    printf("\nDate: %d\n", d1.date);
    printf("Month: %\n", d1.month);
    printf("Year: %d\n", d1.year);
}

int main() {
    struct Date d1;


    inputDate(&d1);
    displayDate(d1);

    return 0;
}