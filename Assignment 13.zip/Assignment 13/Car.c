#include <stdio.h>
#include <string.h>

struct Car    {
    int carid;
    char carname[50];
    float sellingprice;
    int modelnumber;
    
};

int main() {
    struct Car cr;

    
    cr.carid = 1;
    strcpy(cr.carname, "Mahindra Thar"); 
    cr.sellingprice = 1500000.00;
    cr.modelnumber=123456789;
    


    printf("CAR Details:\n");
    printf("carID: %d\n", cr.carid);
    printf(" Car Name: %s\n", cr.carname);
    printf("Selling price of a car: %.2f\n", cr.sellingprice);
    printf("modelnumber: %.2f\n",cr.modelnumber);
     

    return 0;
}
