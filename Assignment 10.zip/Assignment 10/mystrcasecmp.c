#include <stdio.h>
#include <ctype.h> 


int mystrcasecmp(const char* str1, const char* str2);

int main() {
    const char str1[] = "Hello, Prathamesh!";
    const char str2[] = "HELLO, Prathamesh!";
    
    int result = mystrcasecmp(str1, str2);
    
    if (result == 0) {
        printf("Strings are equal.\n");
    } else {
        printf("Strings are not equal.\n");
    }
    
    return 0;
}


int mystrcasecmp(const char* str1, const char* str2) {
    while (*str1 && *str2) {
        char c1 = toupper(*str1);
        char c2 = toupper(*str2);
        
        if (c1 != c2) {
            return c1 - c2;
        }
        
        str1++;
        str2++;
    }
    
    
    if (!(*str1) && !(*str2)) {
        return 0; 
    } else {
        
        return *str1 - *str2;
    }
}
