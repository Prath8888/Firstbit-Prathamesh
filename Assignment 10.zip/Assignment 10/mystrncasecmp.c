#include <stdio.h>
#include <ctype.h> // For toupper, tolower functions

// Function declaration
int mystrncasecmp(const char* str1, const char* str2, size_t n);

int main() {
    const char str1[] = "Hello, World!";
    const char str2[] = "HELLO, world!";
    size_t n = 10; // Number of characters to compare
    
    int result = mystrncasecmp(str1, str2, n);
    
    if (result == 0) {
        printf("First %zu characters are equal.\n", n);
    } else if (result < 0) {
        printf("First %zu characters of '%s' are less than '%s'.\n", n, str1, str2);
    } else {
        printf("First %zu characters of '%s' are greater than '%s'.\n", n, str1, str2);
    }
    
    return 0;
}

// Function definition
int mystrncasecmp(const char* str1, const char* str2, size_t n) {
    size_t i = 0;
    
    while (i < n && str1[i] != '\0' && str2[i] != '\0') {
        char c1 = toupper(str1[i]);
        char c2 = toupper(str2[i]);
        
        if (c1 != c2) {
            return c1 - c2;
        }
        
        i++;
    }
    
    // Check if we reached the end of either string or n characters
    if (i == n) {
        return 0; // Strings are equal up to n characters
    } else {
        return str1[i] - str2[i]; // Compare remaining characters
    }
}
