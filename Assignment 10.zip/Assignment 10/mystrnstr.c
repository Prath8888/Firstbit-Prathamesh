#include <stdio.h>
#include <stddef.h> // For size_t

// Function declaration
char* mystrnstr(const char* haystack, const char* needle, size_t n);

int main() {
    const char haystack[] = "Hello, World! This is a sample text.";
    const char needle[] = "World";
    size_t n = 20; // Number of characters to search within
    
    char* result = mystrnstr(haystack, needle, n);
    
    if (result != NULL) {
        printf("Substring '%s' found within the first %zu characters.\n", needle, n);
        printf("Position: %ld\n", result - haystack);
    } else {
        printf("Substring '%s' not found within the first %zu characters.\n", needle, n);
    }
    
    return 0;
}

// Function definition
char* mystrnstr(const char* haystack, const char* needle, size_t n) {
    size_t needle_len = 0;
    const char* h = haystack;
    
    // Calculate length of needle
    while (needle[needle_len] != '\0') {
        needle_len++;
    }
    
    // Edge case: needle is empty
    if (needle_len == 0) {
        return (char*)haystack;
    }
    
    // Iterate through haystack, up to n characters
    while (*h != '\0' && (h - haystack) < n) {
        const char* hay = h;
        const char* need = needle;
        
        // Compare needle with current haystack position
        while (*hay != '\0' && *need != '\0' && *hay == *need) {
            hay++;
            need++;
        }
        
        // Check if entire needle was found
        if (*need == '\0') {
            return (char*)h; // Return pointer to start of found substring
        }
        
        h++;
    }
    
    return NULL; // Needle not found within the first n characters
}
