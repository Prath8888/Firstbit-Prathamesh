#include <stdio.h>

char* mystrstr(const char* Pratham, const char* phulari);

int main() {
    const char Pratham[] = "Hello, prathamesh! How are you.";
    const char phulari[] = "prathamesh!";
    char* result = mystrstr(Pratham, phulari);
    
    if (result != NULL) {
        printf("Substring found at position: %ld\n", result - Pratham);
    } else {
        printf("Substring not found.\n");
    }
    
    return 0;
}


char* mystrstr(const char* Pratham, const char* phulari) {
    if (*phulari == '\0') {
        return (char*)Pratham; 
    }
    
    while (*Pratham != '\0') {
        const char* h = Pratham;
        const char* n = phulari;
        
        while (*h == *n && *n != '\0') {
            h++;
            n++;
        }
        
        if (*n == '\0') {
            return (char*)Pratham; // Needle found
        }
        
        Pratham++;
    }
    
    return NULL; // Needle not found
}
