#include <stdio.h>


char* mystrrchr(const char* str, int character);

int main() {
    const char str[] = "phulari";
    int character = 'o'; 
    
    char* result = mystrrchr(str, character);
    
    if (result != NULL) {
        printf("Last occurrence of character '%c' found at position: %ld\n", character, result - str);
    } else {
        printf("Character '%c' not found.\n", character);
    }
    
    return 0;
}


char* mystrrchr(const char* str, int character) {
    const char* last_occurrence = NULL;
    
    
    while (*str != '\0') {
        if (*str == character) {
            last_occurrence = str; 
        }
        str++;
    }
    
    if (character == '\0') {
        return (char*)str; 
    }
    
    return (char*)last_occurrence; 
}
