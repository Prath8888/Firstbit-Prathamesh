#include <stdio.h>

void mystrncpy(char *dest, const char *src, size_t n) {
    size_t i;

    // Copy up to n characters from src to dest
    for (i = 0; i < n && src[i] != '\0'; i++) {
        dest[i] = src[i];
    }

    // If there are any remaining bytes to fill, pad them with '\0'
    for ( ; i < n; i++) {
        dest[i] = '\0';
    }
}

int main() {
    char src[] = "Hello, World!";
    char dest[20];

    mystrncpy(dest, src, 5);
    printf("Copied string: %s\n", dest); // Output: "Hello"

    mystrncpy(dest, src, 20);
    printf("Copied string: %s\n", dest); // Output: "Hello, World!"

    return 0;
}
