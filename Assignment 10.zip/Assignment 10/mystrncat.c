#include <stdio.h>

// Function declaration
char* mystrncat(char* dest, const char* src, size_t n);

int main() {
    char dest[50] = "Hello, ";
    const char src[] = "World!";
    size_t n = 5; // Number of characters to concatenate
    
    mystrncat(dest, src, n);
    
    printf("Concatenated string: %s\n", dest);
    
    return 0;
}

// Function definition
char* mystrncat(char* dest, const char* src, size_t n) {
    char* original_dest = dest; // Store the original pointer to dest
    
    // Move dest pointer to the end of dest string
    while (*dest != '\0') {
        dest++;
    }
    
    // Copy up to n characters from src to dest
    while (*src != '\0' && n > 0) {
        *dest++ = *src++;
        n--;
    }
    
    // Append null terminator to dest
    *dest = '\0';
    
    return original_dest; // Return pointer to the beginning of dest
}
