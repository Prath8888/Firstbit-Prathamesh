#include <stdio.h>

// Function declaration
char* mystrchr(const char* str, int character);

int main() {
    const char str[] = "Hello, World!";
    int character = 'o'; // Character to search for
    
    char* result = mystrchr(str, character);
    
    if (result != NULL) {
        printf("Character '%c' found at position: %ld\n", character, result - str);
    } else {
        printf("Character '%c' not found.\n", character);
    }
    
    return 0;
}

// Function definition
char* mystrchr(const char* str, int character) {
    while (*str != '\0') {
        if (*str == character) {
            return (char*)str; // Found the character
        }
        str++;
    }
    
    // Check for the null terminator (end of string)
    if (character == '\0') {
        return (char*)str; // Character is '\0', return end of string
    }
    
    return NULL; // Character not found
}
