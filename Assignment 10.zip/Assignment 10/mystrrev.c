#include <stdio.h>
#include <string.h>

// Function declaration
char* mystrrev(char* str);

int main() {
    char str[] = "Hello, World!";
    
    printf("Original string: %s\n", str);
    
    mystrrev(str);
    
    printf("Reversed string: %s\n", str);
    
    return 0;
}

// Function definition
char* mystrrev(char* str) {
    if (str == NULL) {
        return NULL;
    }
    
    int length = strlen(str);
    char temp;
    
    for (int i = 0; i < length / 2; i++) {
        temp = str[i];
        str[i] = str[length - i - 1];
        str[length - i - 1] = temp;
    }
    
    return str;
}
