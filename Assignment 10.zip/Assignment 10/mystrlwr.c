#include<stdio.h>
int mystrupr(char str[20]);

int main()
{
 
	char str[20];
	int i;

	printf("Enter string:\n");
	gets(str);

	mystrupr(str);
	printf("string in uppercase is \n");
	puts(str);

	return 0;

}

int mystrupr(char str[20]) {
	int i;
       
	for(i=0; str[i]!='\0'; i++) 
	{
		if(str[i]>='A'&& str[i]<='Z') 
		{
		
		
			str[i]=str[i]+32;
		}
		}             
		
	}

	


