#include <stdio.h>

// Function declaration
int mystrncmp(const char* str1, const char* str2, size_t n);

int main() {
    const char str1[] = "Hello, buddy";
    const char str2[] = "Hello, pratham!";
    size_t n = 8; 
    
    int result = mystrncmp(str1, str2, n);
    
    if (result == 0) {
        printf("First %d characters are equal.\n", n);
    } else if (result < 0) {
        printf("First %d characters of '%s' are less than '%s'.\n", n, str1, str2);
    } else {
        printf("First %d characters of '%s' are greater than '%s'.\n", n, str1, str2);
    }
    
    return 0;
}

// Function definition
int mystrncmp(const char* str1, const char* str2, size_t n) {
    while (n > 0 && *str1 && *str2) {
        if (*str1 != *str2) {
            return (*str1 - *str2);
        }
        str1++;
        str2++;
        n--;
    }
    
    if (n == 0 || (*str1 == '\0' && *str2 == '\0')) {
        return 0; 
    } else {
        return (*str1 - *str2); 
    }
}
