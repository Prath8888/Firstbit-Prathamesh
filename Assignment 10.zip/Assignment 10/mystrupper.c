#include<stdio.h>
int mystrlwr(char str[20]);

int main()
{
 
	char str[20];
	int i;

	printf("Enter string:\n");
	gets(str);

	mystrlwr(str);
	printf("string in uppercase is:");
	puts(str);

	return 0;

}

int mystrlwr(char str[20]) {
	int i;
      
	for(i=0; str[i]!='\0'; i++) 
	{
		if(str[i]>='a'&& str[i]<='z') 
		{
			str[i]=str[i]-32;
		}
		}             
		
	}

	


