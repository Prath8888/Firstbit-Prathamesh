#include <stdio.h>
#include <string.h>


int main() {
    char str[15];
    char searchcharacter;
    int flag = 0;

    
    printf("Enter a string: ");
    gets(str);


    str[strcspn(str, "\n")] = '\0';

    
    printf("Enter a character to search: ");
    scanf(" %c", &searchcharacter);

    
    for (int i = 0; i < strlen(str); i++) {
        if (str[i] == searchcharacter) {
            flag = 1;
            break;
        }
    }

    
    if (flag) {
        printf("Character '%c' found in the string.\n", searchcharacter);
    } else {
        printf("Character '%c' not found in the string.\n", searchcharacter);
    }

    return 0;
}
