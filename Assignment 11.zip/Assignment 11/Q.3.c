#include <stdio.h>
#include <string.h>

void removeNthIndexChar(char *str, int n) {
    int len = strlen(str);

    
    if (n < 0 || n >= len) {
        printf("Invalid index\n");
        return;
    }

    
    for (int i = n; i < len - 1; i++) {
        str[i] = str[i + 1];
    }

    
    str[len - 1] = '\0';
}

int main() {
    char str[] = "Hello, World!";
    int n = 5; 

    printf("Original string: %s\n", str);
    removeNthIndexChar(str, n);
    printf("Modified string: %s\n", str);

    return 0;
}
