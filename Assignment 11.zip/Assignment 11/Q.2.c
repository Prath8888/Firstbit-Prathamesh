#include<stdio.h>
void replacechar(char *str, char find, char replace) {
    while (*str != '\0') {
        if (*str == find) {
            *str = replace;
        }
        str++;
    }
}
int main()
{
	char pratham[]="Prathamesh";
	printf("original string:%s",pratham);
	
	replacechar(pratham,'a','$');
	printf("Modified string:%s",pratham);
	return 0;
}
