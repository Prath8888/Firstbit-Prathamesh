#include <stdio.h>

int countVowels(const char *str) {
    int count = 0;
    while (*str != '\0') {
        char c = *str;
        // Check if the character is a vowel
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
            c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
            count++;
        }
        str++;
    }
    return count;
}

int main() {
    char str[] = "Hello, World!";
    printf("Original string: %s\n", str);

    int vowelCount = countVowels(str);
    printf("Number of vowels: %d\n", vowelCount);

    return 0;
}
