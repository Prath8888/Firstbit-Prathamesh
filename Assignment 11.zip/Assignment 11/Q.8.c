#include <stdio.h>


int countWords(const char *str) {
    int count = 0;
    int flag = 0;

    while (*str != '\0') {
        if (*str == ' ' || *str == '\t' || *str == '\n') {
            flag = 0;
        } else if (!flag) {
            flag = 1;
            count++;
        }
        str++;
    }

    return count;
}

int main() {
    char str[] = "Hello, World! This is a test string.";
    printf("Original string: \"%s\"\n", str);

    int wordCount = countWords(str);
    printf("Number of words: %d\n", wordCount);

    return 0;
}
