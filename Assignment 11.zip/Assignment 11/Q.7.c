#include <stdio.h>
#include <string.h>

void removeOddIndexChars(char *str) {
    int length = strlen(str);
    int j = 0; // Index for the new modified string

    for (int i = 0; i < length; i++) {
        if (i % 2 == 0) {
            str[j++] = str[i];
        }
    }

    // Null-terminate the modified string
    str[j] = '\0';
}

int main() {
    char str[] = "Hello, World!";
    printf("Original string: %s\n", str);

    removeOddIndexChars(str);
    printf("Modified string (without odd index characters): %s\n", str);

    return 0;
}
