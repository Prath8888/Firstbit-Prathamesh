#include <stdio.h>

void replaceSpaces(char *str, char specialSymbol) {
    while (*str != '\0') {
        if (*str == ' ') {
            *str = specialSymbol;
        }
        str++;
    }
}

int main() {
    char str[] = "Hello, World! Welcome to C programming.";
    char specialSymbol = '@'; 

    printf("Original string: %s\n", str);

    replaceSpaces(str, specialSymbol);
    printf("Modified string: %s\n", str);

    return 0;
}
