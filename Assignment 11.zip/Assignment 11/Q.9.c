#include <stdio.h>

int stringLength(const char *str) {
    int length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

int compareStrings(const char *str1, const char *str2) {
    int i = 0;
    while (str1[i] != '\0' && str2[i] != '\0') {
        if (str1[i] != str2[i]) {
            return (str1[i] - str2[i]);
        }
        i++;
    }
    return (str1[i] - str2[i]);
}

int main() {
    char str1[100], str2[100];

    printf("Enter the first string: ");
    gets(str1); 
    printf("Enter the second string: ");
    gets(str2);

    int len1 = stringLength(str1);
    int len2 = stringLength(str2);

    if (compareStrings(str1, str2) > 0) {
        printf("The larger string is: %s\n", str1);
    } else if (compareStrings(str1, str2) < 0) {
        printf("The larger string is: %s\n", str2);
    } else {
        printf("Both strings are equal.\n");
    }

    return 0;
}
