#include <stdio.h>
#include <string.h>

void swapFirstLast(char *str) {
    int len = strlen(str);

    // Check if the string has at least two characters
    if (len < 2) {
        printf("String too short to swap characters.\n");
        return;
    }

    // Swap the first and last characters
    char temp = str[0];
    str[0] = str[len - 1];
    str[len - 1] = temp;
}

int main() {
    char str[] = "Hello, World!";
    printf("Original string: %s\n", str);

    swapFirstLast(str);
    printf("Modified string: %s\n", str);

    return 0;
}
